function d = ComputeCovDist(c1, c2, distMeasure)
% ComputeCovDist - computes distance between two covariance matrices
% 
% Input:
%       c1, c2 - a pair of covariance matrices
%       distMeasure - distance metric to be used. Currently two metric types are supported:
%                     1. Affine Invariant Riemannian Metric (AIRM)
%                     2. Log-Euclidean Riemannian Metric (LERM)  
%
% Output:
%       d - computed distance
%

switch distMeasure
     case 'AIRM'
        % AIRM = Affine Invariant Riemannian Metric
        c1_ = c1^(-.5);
        [U,D]=eig(c1_*c2*c1_);
        D = max(D,0);
        d = sqrt(trace(U*diag(log(diag(D)).^2)*U'));
        
        % validate that the result is identical to the Forstener&Moonen's metric for covariance matrices
        % assert(abs(d-sqrt(sum(log(eig(c1,c2)).^2)))<1e-6);

     case 'LERM'
        % LERM = Log-Euclidean Riemannian Metric
        [U1,D1]=eig(c1);
        [U2,D2]=eig(c2);
        X = U1*diag(log(diag(D1)))*U1'-U2*diag(log(diag(D2)))*U2';
        d = sqrt(trace(X*X'));
end
