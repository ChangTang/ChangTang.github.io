function weights=makeweights(edges,vals,GradientCov,valScale)
%% Color distance
valColorDistances=sqrt(sum((vals(edges(:,1),:)-vals(edges(:,2),:)).^2,2));
% valDistances=normalize(valDistances); %Normalize to [0,1]
% weights=exp(-valScale*valDistances);

%% Gradient Covariance Distance
edgeNum=size(edges,1);
for i=1:edgeNum
    index=edges(i,:);
    Cov1=GradientCov{index(1)};
    Cov2=GradientCov{index(2)};
    valCovDistances(i)=ComputeCovDist(Cov1,Cov2,'LERM');
end
valDistances=0.4*valColorDistances+0.6*valCovDistances';
valDistances=normalize(valDistances); %Normalize to [0,1]
weights=exp(-valScale*valDistances);
