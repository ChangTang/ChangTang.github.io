This demo code is for Ref. [1], and can only be used for non-comercial purpose. 
If you use our code, please cite our paper Ref. [1].

Code Author: Chang Tang
Email: happytangchang@gmail.com
Date: 2016.10.21
[1] Chang Tang, Jin Wu, Yonghong Hou, Pichao Wang, Wanqing Li, "A spectral and spatial approach of coarse-to-fine blurred image region detection", IEEE Signal Processing Letters, 23(11), 1652-1656, 2016.

BIB:
@article{Tang2016Blur,
  title={A spectral and spatial approach of coarse-to-fine blurred image region detection},
  author={Tang, Chang and Wu, Jin and Hou, Yonghong and Wang, Pichao and Li, Wanqing},
  journal={IEEE Signal Processing Letters},
  volume={23},
  number={11},
  pages={1652--1656},
  year={2016},
}

Usage:
1) Put your source images to the path 'images\';
2) Run 'BlurDemo'.
3) The results will be saved in "Res\"


The code is tested on Windows 7 64bit with MATLAB R2013a.
This code is the preliminary version. We appreciate any comments/suggestions.
