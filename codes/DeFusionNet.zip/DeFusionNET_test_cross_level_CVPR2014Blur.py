
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import matplotlib.pylab as pylab
import matplotlib.cm as cm
import scipy.misc
import Image
import scipy.io
import os
import scipy.misc
import time

# get_ipython().magic(u'matplotlib inline')
# Make sure that caffe is on the python path:
caffe_root = '../'
import sys
sys.path.insert(0, caffe_root + 'python')

import caffe

EPSILON = 1e-8


# In[ ]:


def getFileList( p ):
       p = str( p )
       if p=="":
             return [ ]
       #p = p.replace( "/","/")
       if p[ -1] != "/":
            p = p+"/"
       a = os.listdir( p )
       b = [ x   for x in a if os.path.isfile( p + x ) ]
       return b
   

#data_root = '/home/xwhu/dataset/MSRA10K/MSRA10K_Imgs_GT/Imgs/'
#with open('../data/msra10k/test.txt') as f:
   
data_root = '/media/chang/D/BaiduYun/ProgramRunning/DataSets/BlurDtection/CVPR2014/BlurTrainingTesting/Imgs/'
with open('/media/chang/D/BaiduYun/ProgramRunning/DataSets/BlurDtection/CVPR2014/BlurTrainingTesting/test.txt') as f:

#data_root = '/media/chang/D/BaiduYun/ProgramRunning/DataSets/BlurDtection/JNBD/Imgs/'
#with open('/media/chang/D/BaiduYun/ProgramRunning/DataSets/BlurDtection/JNBD/test.txt') as f:
   
#data_root = '/home/xwhu/dataset/HKU-IS/imgs/'
#with open('../data/HKU-IS/test.txt') as f:    
   
#data_root = '/home/xwhu/dataset/PASCAL-S/input/'
#with open('../data/PASCAL-S/test.txt') as f:    
   
#data_root = '/home/xwhu/dataset/SOD/image/'
#with open('../data/SOD/test.txt') as f: 
   
#data_root = '/home/xwhu/dataset/DUT-OMRON/DUT-OMRON-image/'
#with open('../data/DUT-OMRON/test.txt') as f: 
   test_name = f.readlines()
   
test_lst = [data_root+x.strip() for x in test_name]


# In[ ]:


#remove the following two lines if testing with cpu
#caffe.set_mode_gpu()
# choose which GPU you want to use
#caffe.set_device(0)
caffe.SGDSolver.display = 0
# load net
net = caffe.Net('DeFusionNET_test_cross_level_CA_blur.prototxt', 'snapshot/DeFusionNET_blur_iter_20000.caffemodel', caffe.TEST)


# In[ ]:


#Visualization
def plot_single_scale(scale_lst, name_lst, size):
    pylab.rcParams['figure.figsize'] = size, size/2
    plt.figure()
    for i in range(0, len(scale_lst)):
        s = plt.subplot(1,5,i+1)
        s.set_xlabel(name_lst[i], fontsize=10)
        if name_lst[i] == 'Source':
            plt.imshow(scale_lst[i])
        else:
            plt.imshow(scale_lst[i], cmap = cm.Greys_r)
        s.set_xticklabels([])
        s.set_yticklabels([])
        s.yaxis.set_ticks_position('none')
        s.xaxis.set_ticks_position('none')
    plt.tight_layout()


# In[2]:


usedtime = 0;

for idx in range(len(test_lst)):

    # load image
    img = Image.open(test_lst[idx])

    if img.mode == 'L':
        img_temp = np.zeros((img.size[1], img.size[0], 3))
        img_temp[:,:,0] = img
        img_temp[:,:,1] = img
        img_temp[:,:,2] = img
        img = img_temp
    
    
    img = np.array(img, dtype=np.uint8)
    im = np.array(img, dtype=np.float32)
    im = im[:,:,::-1]
    im -= np.array((104.00698793,116.66876762,122.67891434))
    im = im.transpose((2,0,1))

    # load gt
    gt = Image.open(test_lst[idx])

    # shape for input (data blob is N x C x H x W), set data
    net.blobs['data'].reshape(1, *im.shape)
    net.blobs['data'].data[...] = im
    # run net and take argmax for prediction
    
    start_time = time.clock()
    net.forward()
    usedtime = usedtime + time.clock() - start_time
    #avgtime = usedtime/(idx+1)
    
    out1 = net.blobs['sigmoid-dsn1'].data[0][0,:,:]
    out2 = net.blobs['sigmoid-dsn2'].data[0][0,:,:]
    out3 = net.blobs['sigmoid-dsn3'].data[0][0,:,:]
    out4 = net.blobs['sigmoid-dsn4'].data[0][0,:,:]
    out5 = net.blobs['sigmoid-dsn5'].data[0][0,:,:]
    out6 = net.blobs['sigmoid-dsn6'].data[0][0,:,:]
    fuse = net.blobs['sigmoid-fuse'].data[0][0,:,:]
    
    out3a = net.blobs['sigmoid-dsn3a'].data[0][0,:,:]
    out4a = net.blobs['sigmoid-dsn4a'].data[0][0,:,:]
    out5a = net.blobs['sigmoid-dsn5a'].data[0][0,:,:]
    out1a = net.blobs['sigmoid-dsn1a'].data[0][0,:,:]
    out2a = net.blobs['sigmoid-dsn2a'].data[0][0,:,:]
    out6a = net.blobs['sigmoid-dsn6a'].data[0][0,:,:]
    
    res = (out1+out2+out6+out1a+out2a+out6a+out3a + out4a + out5a + out3 + out4 + out5 + fuse) / 13
    res = (res - np.min(res) + EPSILON) / (np.max(res) - np.min(res) + EPSILON)
    res1 = (out1+out1a) / 2
    res2 = (out2+out2a) / 2
    res3 = (out3+out3a) / 2
    res4 = (out4+out4a) / 2
    res5 = (out5+out5a) / 2
    res6 = (out6+out6a) / 2
    res1 = (res1 - np.min(res1) + EPSILON) / (np.max(res1) - np.min(res1) + EPSILON)
    res2 = (res2 - np.min(res2) + EPSILON) / (np.max(res2) - np.min(res2) + EPSILON)
    res3 = (res3 - np.min(res3) + EPSILON) / (np.max(res3) - np.min(res3) + EPSILON)
    res4 = (res4 - np.min(res4) + EPSILON) / (np.max(res4) - np.min(res4) + EPSILON)
    res5 = (res5 - np.min(res5) + EPSILON) / (np.max(res5) - np.min(res5) + EPSILON)
    res6 = (res6 - np.min(res6) + EPSILON) / (np.max(res6) - np.min(res6) + EPSILON)
 
    
    name_lst = ['SO1', 'SO2', 'SO3', 'SO4', 'SO5']
    name_lst = ['SO6', 'Fuse', 'Result', 'Source', 'GT']
 
    # save image
    scipy.misc.imsave('./DeFusionNET_NOCRF/' + test_name[idx][:-5] + '.png',res)
    scipy.misc.imsave('./DeFusionNET_NOCRF_OUT1/' + test_name[idx][:-5] + '.png',res1)
    scipy.misc.imsave('./DeFusionNET_NOCRF_OUT2/' + test_name[idx][:-5] + '.png',res2)
    scipy.misc.imsave('./DeFusionNET_NOCRF_OUT3/' + test_name[idx][:-5] + '.png',res3)
    scipy.misc.imsave('./DeFusionNET_NOCRF_OUT4/' + test_name[idx][:-5] + '.png',res4)
    scipy.misc.imsave('./DeFusionNET_NOCRF_OUT5/' + test_name[idx][:-5] + '.png',res5)
    scipy.misc.imsave('./DeFusionNET_NOCRF_OUT6/' + test_name[idx][:-5] + '.png',res6)
    
    if (idx+1)%100 == 0:
        print("%d / %d, time: %f s" % (idx+1,len(test_lst),usedtime/(idx+1)))

print 'done!'

