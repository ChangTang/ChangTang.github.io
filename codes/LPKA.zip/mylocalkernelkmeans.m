function [H_normalized]= mylocalkernelkmeans(K,A,cluster_count,beta)

num = size(K,1);
opt.disp = 0;
K0 = zeros(num);
BetaK0 = zeros(num);
for i =1:num
    Ki = zeros(num);
    Ki(A(:,i),A(:,i)) = K(A(:,i),A(:,i));
    K0 = K0 + Ki;  
%     
%     Kmui=A*K*A';
%     DKmui = sum(Kmui,2);
%     D = spdiags(DKmui,0,size(DKmui,1),size(DKmui,1));
%     Lmui = D-Kmui;
%     BetaKi = A'*Lmui*A;
%     BetaK0 = BetaK0 + BetaKi;
%     
%     K0 = K0 - beta*BetaK0;
end

    DK = sum(K,2);
    D = spdiags(DK,0,size(DK,1),size(DK,1));
    D=full(D);
    K=full(K);
    Lmui = D-K;
    K0 = K0 - beta*Lmui;


K0= (K0+K0')/2;
% tic;
[H,~] = eigs(double(K0),cluster_count,'LA',opt);
% [He,~] = eig(K0);
% toc;
% tic;
% K0 = gpuArray(K0);
% [A2,B2] = eigs(K0,cluster_count,'LA',opt);              % ������ֵ����������
% H2 = gather(A2);
% toc;
% H_normalized = H ./ repmat(sqrt(sum(H.^2, 2)), 1,cluster_count);
H_normalized = H;