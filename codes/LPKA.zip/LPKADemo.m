clear
clc;
warning off
addpath(genpath('.\'));
Datapath = 'Data\'; % Please download the demo datasets from: https://pan.baidu.com/s/13ieB5O2EDgVB50hTimMo6w
dataName={'Deng' 'Ginhoux' 'Ting' 'Treutlin' 'Buettner' 'Pollen' 'Tasic' 'Zeisel' 'Macosko'};
for i=5:length(dataName);
    dataN=dataName{i};
    load([Datapath,dataN,'_Kmatrix'],'KH','Y');
    if i==3
        Y=Y';
    end
    
    KH = kcenter(KH);
    KH = knorm(KH);
    num = size(KH,1);
    numclass = length(unique(Y));
    numker = size(KH,3);
    %%%%%%%%---Average---%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    gamma0 = ones(numker,1)/numker;
    avgKer = mycombFun(KH,gamma0);

    lambdaset3 = 2.^[-3:3:3];
    tauset3 = [0.2:0.1:0.4];
    betaset3 = [0.01 0.1 1 10 100];
    accval3 = zeros(length(tauset3),length(lambdaset3),length(betaset3));
    nmival3 = zeros(length(tauset3),length(lambdaset3),length(betaset3));
    purval3 = zeros(length(tauset3),length(lambdaset3),length(betaset3));
    arival3 = zeros(length(tauset3),length(lambdaset3),length(betaset3));
    for it =1:length(tauset3)
        numSel = round(tauset3(it)*num);
        A3 = genarateNeighborhood(avgKer,numSel);
        HE3 = calHessian(KH,A3);
        for il =1:length(lambdaset3)
            for ib = 1:length(betaset3)
                disp(['Processing data: ',dataN,', Tau: ',num2str(tauset3(it)),', Lambda: ',num2str(lambdaset3(il)),', Beta: ',num2str(betaset3(ib))]);
                [H_normalized3,gamma3,obj3] = mylocalizedregmultikernelclustering(KH,HE3,A3,...
                    numclass,lambdaset3(il),betaset3(ib));
%                 if lambdaset3(il)==1&&tauset3(it)==0.3&&betaset3(ib)==1
%                     objFile=[objPath,dataN,'_obj.mat'];
%                     save(resFile,'obj3');
%                 end
                res3 = myNMIACC(H_normalized3,Y,numclass);
                accval3(it,il,ib) = res3(1); % ACC
                nmival3(it,il,ib) = res3(2); % NMI 
                purval3(it,il,ib) = res3(3); % PURITY 
                arival3(it,il,ib) = res3(4); % ARI 
            end
        end
    end
    MaxACC=max(max(max(accval3)));
    MaxNMI=max(max(max(nmival3)));
    MaxPUR=max(max(max(purval3)));
    MaxARI=max(max(max(arival3)));
end
