function [ A,E,iter1 ] = weighted_projection( D,lambda, w, tol, maxiter )
%MC_RPCA_MIXED implements the inexact augmented lagrange multiplier
% method for matrix recovery with erase and sparse noise
%   D    - m*n matrix of observations
%
% lambda - weight on sparse error term in the cost function
%
%   w    - weighting matrix
%
% tol    - tolerance for stopping criterion
%    -DEFAULT 1e-3 if omitted or -1
%
% maxiter - maximum number of iterations
%    -DEFAULT 500 if omitted or -1
%
% Model:
%   min |A|_* +lambda*|E|_1
%   subj W*(A+E)=W*D;

[m,n] = size(D);
if nargin < 4
%     tol = 1e-3;
tol=1e-10;
elseif tol == -1
%     tol = 1e-3;
tol=1e-10;
end
if nargin < 5
    maxiter = 500;
elseif maxiter == -1
    maxiter = 500;
end

rho=1.2;%1.1+2.5*rho_s;  %1.2
% lambda =8;%1/sqrt(m);
norm_two = lansvd(D, 1, 'L');   %computes the 1 largest singular value
muk=1000/norm_two;
d_norm=norm(D,'fro');

Ek=zeros(m,n);Yk=zeros(m,n);
iter1=0;
converged1=false;
sv =3;
obj=[];
while ~converged1
    iter1 = iter1+1;
    disp(iter1);
    [U, S, V]=lansvd(D-Ek+(1/muk)*Yk,sv,'L');
%     [U,S,V] = svd(D-Ek+(1/muk)*Yk);
    diagS = diag(S);
    diagS = diagS(1:sv);
    svn = length(find(diagS > 1/muk));
    svp = svn;
    
    ratio = diagS(1:end-1)./diagS(2:end);
    [max_ratio, max_idx] = max(ratio);
    if max_ratio > 2
        svp = min(svn, max_idx);
    end
    if svp < sv %|| iter < 10
        sv = min(svp + 1, n);
    else
        sv = min(svp + 10, n);
    end
   Ak=U(:,1:svp)*diag(diagS(1:svp)-1/muk)*V(:,1:svp)';
%     Ak = U*(shrink(S,1/muk))*V';
    
    Ek = shrink(D-Ak+(1/muk)*Yk,(lambda/muk)*w);
    
    
    Yk=Yk+muk*(D-Ak-Ek);
    muk=rho*muk;
   objvalue=rank(Ak)+lambda*norm(Ek,1);
   obj=[obj objvalue];
   disp(['objvalue:',num2str(objvalue)]);
     stopCriterion = norm(D-Ak-Ek, 'fro') / d_norm;
      disp([ ' r(F) ' num2str(rank(Ak))...
            ' |E|_0 ' num2str(length(find(abs(Ek)>0)))...
            ' stopCriterion ' num2str(stopCriterion)  ' iter1 ' num2str(iter1) ' mu ' num2str(muk)]);
    if stopCriterion < tol
        converged1 = true;
    end   
    if ~converged1&&iter1>=maxiter
        disp('Maximum iterations reached');
        converged1=true;
    end
end

A=Ak;
E=Ek;
end

