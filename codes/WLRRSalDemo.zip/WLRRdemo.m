% This is a demon code for:
% Chang Tang, Pichao Wang, Changqing Zhang, Wanqing Li, "Salient Object Detection via Weighted Low Rank Matrix Recovery", IEEE Signal Processing Letters (IEEE SPL)24(4), 490-494, 2017.
clc;clear;
close all;
%% compile mex file
%disp 'compile mex files ... ...'
%compile;
%disp 'compile done'
%% Path settings
inputImgPath = 'DataSets\2DSaliency\ECSSD\Imgs\';       % input image path
% gtPath = '\'; for evaluation  
resSalPath = 'ECSSD1000';                     % result path
if ~exist(resSalPath, 'file')
    mkdir(resSalPath);
end
addpath(genpath('Dependencies'));
addpath('PROPACK');
%% Parameter settings
paras.alpha = [1.1];
paras.beta = [0.35];   
paras.delta = 0.05;
imgFiles = dir(fullfile(inputImgPath, '*.jpg'))
for indImg = 1:length(imgFiles)    
    % read image
    imgPath = fullfile(inputImgPath, imgFiles(indImg).name);
%     gtPath=fullfile(gtPath,imgFiles(indImg).name(1:end-4));
%     gtPath=[gtPath, '.png'];
    img.RGB = imread(imgPath);
%     imshow(img.RGB);title('test');
    Temp=img.RGB;
    [H W D]=size(img.RGB);
    if D==1
        delete  imgPath;
        delete  gtPath;
        continue;
    end
    img.name = imgFiles(indImg).name(1:end-4);  
    TestRes=fullfile(resSalPath, [img.name,'.jpg']);
   % if exist(TestRes,'file')
            % calculate saliency map via structured matrix decomposition
    tic;
            [salMap, midRes] = ComputeSaliency(img,paras); 
            imshow([salMap midRes],[]);
            toc;
%     subplot(1,2,1);imshow(img.RGB,[]);title('Input RGB Image');
%     subplot(1,2,2);imshow(salMap,[]);title('Saliency Map of Our SMD Method');
        
    % save saliency map    
    salPath = fullfile(resSalPath, strcat(img.name, '.jpg'));  
%     imwrite(salMap,salPath);
    
    fprintf('The saliency map: %s is saved in the file: SAL_MAP \n', img.name);
    fprintf('%s/%s images have been proces  sed ... Press any key to continue ...\n', num2str(indImg), num2str(length(imgFiles)) );   
%     pause;
   % end

    close all;    
end  

%% Evaluate saliency map

% Method='WLRMR-DUT-OMRON';   
% gtSuffix = '.png';
% salSuffix='.jpg';
% resPath = 'results\';
% if ~exist(resPath,'file')
%     mkdir(resPath);
% end
% 
% % compute Precison-recall curve
% [REC, PRE] = DrawPRCurve(resSalPath, salSuffix, gtPath, gtSuffix, true, true, 'r');
% PRPath = fullfile(resPath, ['PR_',Method,'.mat']);
% save(PRPath, 'REC', 'PRE');
% fprintf('The precison-recall curve is saved in the file: %s \n', resPath);
% 
% % compute ROC curve
% thresholds = [0:1:255]./255;
% [TPR, FPR] = CalROCCurve(resSalPath,salSuffix, gtPath, gtSuffix, thresholds, 'r');    
% ROCPath = fullfile(resPath, ['ROC_',Method,'.mat']); 
% save(ROCPath, 'TPR', 'FPR');
% fprintf('The ROC curve is saved in the file: %s \n', resPath);
% 
% % compute F-measure curve
% setCurve = true;
% [meanP, meanR, meanF] = CalMeanFmeasure(resSalPath, salSuffix, gtPath, gtSuffix, setCurve, 'r');
% FmeasurePath = fullfile(resPath, ['FmeasureCurve_',Method,'.mat']);
% save(FmeasurePath, 'meanF');
% fprintf('The F-measure curve is saved in the file: %s \n', resPath);
% 
% % compute MAE
% MAE = CalMeanMAE(resSalPath, salSuffix, gtPath, gtSuffix);
% MAEPath = fullfile(resPath, ['MAE_',Method,'.mat']);
% save(MAEPath, 'MAE');
% fprintf('MAE: %s\n', num2str(MAE'));
% 
% % compute WF
% Betas = [1];
% WF = CalMeanWF(resSalPath, salSuffix, gtPath, gtSuffix, Betas);
% WFPath = fullfile(resPath, ['WF_',Method,'.mat']);
% save(WFPath, 'WF');
% fprintf('WF: %s\n', num2str(WF'));
% 
% % compute AUC
% AUC = CalAUCScore(resSalPath, salSuffix, gtPath, gtSuffix);
% AUCPath = fullfile(resPath, ['AUC_',Method,'.mat']);
% save(AUCPath, 'AUC');
% fprintf('AUC: %s\n', num2str(AUC'));
% 
% % compute Overlap ratio
% setCurve = false;
% overlapRatio = CalOverlap_Batch(resSalPath, salSuffix, gtPath, gtSuffix, setCurve, '0');
% overlapFixedPath = fullfile(resPath, ['ORFixed_',Method,'.mat']);
% save(overlapFixedPath, 'overlapRatio');
% fprintf('overlapRatio: %s\n', num2str(overlapRatio'));
