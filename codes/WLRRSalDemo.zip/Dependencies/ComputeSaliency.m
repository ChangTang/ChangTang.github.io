function [salMap midRes] = ComputeSaliency(img,paras)
% INPUT:    img - input image
%           paras - parameter setting
% OUTPUT:   saliency map

%% STEP-1. Read an input images and perform preprocessing
[img.height, img.width] = size(img.RGB(:,:,1));
[noFrameImg.RGB, noFrameImg.frame] = RemoveFrame(img.RGB, 'sobel');
[noFrameImg.height, noFrameImg.width, noFrameImg.channel] = size(noFrameImg.RGB);

%% STEP-2. Generate superpixels using SLIC
[sup.label, sup.num, sup.Lab] = PerformSLIC(noFrameImg);
% get superpixel statistics 
sup.pixIdx = cell(sup.num, 1);
sup.pixNum = zeros(sup.num,1);
for i = 1:sup.num
     temp = find(sup.label==i);
     sup.pixIdx{i} = temp;
     sup.pixNum(i) = length(temp);
end
sup.pos = GetNormedMeanPos(sup.pixIdx, noFrameImg.height, noFrameImg.width);

%% STEP-3. Extract features
featImg = ExtractFeature(im2single(img.RGB));
for i = 1:3
    featImg(:,:,i) = mat2gray(featImg(:,:,i)).*255;
end
featMat = GetMeanFeat(featImg, sup.pixIdx);  
featMat = featMat./255;
colorFeatures = featMat(:,1:3);
medianR = median(colorFeatures(:,1)); medianG = median(colorFeatures(:,2)); medianB = median(colorFeatures(:,3));
featMat(:,1:3) = (featMat(:,1:3)-1.2*repmat([medianR, medianG, medianB],size(featMat,1),1))*1.5;
%featMapShow(mapminmax(sum(abs(featMat),2)',0,1), sup.label);
%% Weighted LR decomposition
%% STEP-4. Get high-level priors
% load color prior matrix as used in [X. Shen and Y. Wu, CVPR'12]
if ~exist('colorPriorMat','var')
    fileID = fopen('ColorPrior','rb');
    data = fread(fileID,'double');
    fclose(fileID);
    colorPriorMat = reshape(data(end-399:end), 20, 20);
end
% get the indexes of boundary superpixels
bndIdx = GetBndSupIdx(sup.label);
% get banckground prior by robust background detection [W. Zhu et al., CVPR'14]
colorDistMat = ComputeFeatDistMat(sup.Lab);
[fstReachMat, fstSndReachMat, fstSndReachMat_lowTri] = GetFstSndReachMat(sup.label, sup.num);
[bgPrior, bdCon] = GetPriorByRobustBackgroundDetection(colorDistMat, fstReachMat, bndIdx);
% subplot(1,2,1);featMapShow(bgPrior, sup.label);
[prior centerPrior colorPrior] = GetHighLevelPriors(sup.pos, sup.num, colorPriorMat, colorFeatures, bgPrior);
% subplot(1,2,1);featMapShow(prior, sup.label);
featMapShow(prior, sup.label)
% Prior Threshold
% meanbgPrior=mean(prior)*0.5;
% HighValueIndex=find(prior>=meanbgPrior);
% LowValueIndex=find(prior<meanbgPrior);
% prior(LowValueIndex)=1;
% prior(HighValueIndex)=0.5;
% subplot(1,2,1);featMapShow(prior, sup.label);
% % Prior Threshold
% pre-processing
featMat = repmat(prior,1,53) .* featMat;

%% 5. Weighted LRMR
lambda=0.6;
weighted = repmat(prior,1,53);
weighted=weighted';
weighted=1./(1+exp(weighted));
% weighted=(max(weighted(:))-weighted)./(max(weighted(:))-min(weighted(:)));
[ L, S, iter1 ] = weighted_projection(featMat', lambda, weighted); 
S=S';
%%
for i=1:sup.num
    S_sal(i)=sum(abs(S(i,:)));
    L_sal(i)=sum(abs(S(i,:)));
end
% S_sal = mapminmax(sum(abs(S),1),0,1);

salMap = GetSaliencyMap(S_sal, sup.pixIdx, noFrameImg.frame, true);
midRes=salMap;
%% 6. post-processing
% link boundary superpixels
fstSndReachMat(bndIdx, bndIdx) = 1;
fstSndReachMat_lowTri_Bnd = tril(fstSndReachMat, -1);
[tmpRow, tmpCol] = find(fstSndReachMat_lowTri_Bnd>0);
edge = [tmpRow, tmpCol];
% get the weights on edges
weightOnEdge = ComputeWeightOnEdge(colorDistMat, fstSndReachMat_lowTri_Bnd, paras.delta);
% compute affinity matrix
W = sparse([edge(:,1);edge(:,2)], [edge(:,2);edge(:,1)], [weightOnEdge; weightOnEdge], sup.num, sup.num);

%% STEP-7: Post-processing to get improvements
% parameters for postprocessing
lambada = 0.1;                                              % 0.1
% L_sal = lambada * (1-mapminmax(sum(abs(L),1),0,1)') + (1-lambada) * (1 - mapminmax(bgPrior',0,1)');
L_sal = lambada * L_sal + (1-lambada) * (1 - mapminmax(bgPrior',0,1)')';
S_sal_new = postProcessing(L_sal, S_sal, bdCon, fstReachMat, W, sup);    
% save saliency map
salMap = GetSaliencyMap(S_sal_new, sup.pixIdx, noFrameImg.frame, true);

