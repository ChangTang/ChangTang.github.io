%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demon code for:
% Chang Tang, Lijuan Cao, Jiajia Chen and Xiao Zheng, "Speckle noise reduction for optical coherence tomography images via non-local weighted group low-rank representation",
% Laser Physics Letters, Volume 14, Number 5, 2017.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;
%% Input
Lambda =0.1;
datasetPath='imgs\';
ResPath='Res\';
for j=1:1
    disp(j);
    resName=[ResPath,num2str(j),'.tif'];
    imgName=[datasetPath,num2str(j),'_Raw Image.tif'];
    noisyImg=double(imread(imgName)); 
    tic;
    DenoisedRes=WGLRR(noisyImg,Lambda);
    toc;
    imwrite(DenoisedRes,resName);
end
