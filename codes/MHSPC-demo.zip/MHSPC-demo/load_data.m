function [Dataset] = load_data(dataset_name)
    %% import the dataset
    switch dataset_name
        case 'Indian_Pines'
            A = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\indian_pines_185.mat');
            ground_truth = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\Indian_pines_gt.mat');
        case 'Salinas'
            A = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\Salinas.mat');
            ground_truth = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\Salinas_gt.mat');
        case 'Pavia_University'
            A = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\PaviaU.mat');
            ground_truth = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\PaviaU_gt.mat');    
        case 'KSC'
            A = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\KSC.mat');
            ground_truth = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\KSC_gt.mat');
        case 'Botswana'
            A = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\Botswana.mat');
            ground_truth = importdata('D:\BaiDuYun\ProgrammingRunning\HSIClassification\HyperData\WJ\Botswana_gt.mat');
    end
    %% definition and initialization
    A = double(A);
    minv = min(A(:));
    maxv = max(A(:));
    A = double(A - minv) / double(maxv - minv);
    
    %% Generalize the output
    X = permute(A, [3, 1, 2]);
    X = X(:, :);
    Dataset.X = X; 
    Dataset.A = A;
    Dataset.ground_truth = ground_truth;
end