function map=color_disp(classification_map)

clr={'Green','Red','White','Pink','DarkGrey','Brown','Aqua','Yellow','IndianRed','YellowGreen','Purple','Tan','LightGrey','Wheat','LightGreen','Gray'};
class_name={'Alfalfa','Corn-notill','Corn-mintill','Corn','Grass-Pasture',...
    'Grass-Trees','Grass-pasture-mowed','Hay-windrowed','Oats',...
    'Soybeans-notills','Soybeans-mintills','Soybeans-clean','Wheat',...
    'Whoods','Building-Grass-Trees-Drivers','Stone-Steel-Towers'}; % Indian Pines

% class_name={'Brocoli-green-weeds-1','Brocoli-green-weeds-2','Fallow','Fallow-rough-plow','Fallow-smooth',...
%     'Stubble','Celery','Grapes-untrained','Soil-vinyard-develop',...
%     'Corn-senesced-green-weeds','Lettuce-romaine-4wk','Lettuce-romaine-5wk','Lettuce-romaine-6wk',...
%     'Lettuce-romaine-7wk','Vinyard-untrained','Vinyard-vertical-trellis'}; % Salinas

% class_name={'Asphalt','Meadows','Gravel','Trees','Metal sheets',...
%     'Bare soil','Bitumen','Bricks','Shadow'}; % Pavia

% class_name={'Scrub','Willow-swamp','Cabbage-palm-hammock','Cabbage-palm-oakhammock','Slash-pine',...
%     'Oak-broadleaf-hammock','Hardwood-swamp','Graminoid-marsh','Spartina-marsh',...
%     'Cattail-marsh','Salt-marsh','Mud-flats','Water'}; % KSC

figure;
hold on
% if(st==1)
%     figure;
%     hold on
% end
for i=1:16
    color(i,:)=rgb(clr{i});
%     if(st==1)
%         stem(i,i,'Color',color(i,:));
%     end
end
% if(st==1)
%     legend(class_name,'Location','southeast', 'FontName', 'Times New Roman', 'FontSize', 10);
% end

classification_map_color_r=zeros(size(classification_map,1),size(classification_map,2));
classification_map_color_g=zeros(size(classification_map,1),size(classification_map,2));
classification_map_color_b=zeros(size(classification_map,1),size(classification_map,2));

for i=1:16
    locs=classification_map==i;
    classification_map_color_r(locs)=color(i,1);
    classification_map_color_g(locs)=color(i,2);
    classification_map_color_b(locs)=color(i,3);
end
map=cat(3,classification_map_color_r',classification_map_color_g',classification_map_color_b');

T=affine2d([0 1 0;1 0 0;0 0 1]);
map_diverse=imwarp(map,T);
imshow(map_diverse,'InitialMagnification','fit');

% PicPath = ['C:\Users\Administrator\Desktop\����ͼ\' 'EFDPC.jpg'];
% print('-djpeg','-r300', PicPath);
% for i = 1 : length(class_name)
% %     if i < 9
%         rectangle('Position',[620, 0 + (i-1) * 40,45,32],'FaceColor',rgb(clr{i}));
%         if length(class_name{i}) > 12
%             a = class_name{i};
%             textstr1 = {a(1:12)};
%             textstr2 = {a(13:length(a))};
%           text(670 ,(i-1) * 40 + 8 ,textstr1,'FontName', 'Times New Roman','FontSize',10,'FontWeight','bold');
%           text(670 ,(i-1) * 40 + 25 ,textstr2,'FontName', 'Times New Roman','FontSize',10,'FontWeight','bold');
%         else         
%           text(670 ,(i-1) * 40 + 16 ,class_name{i},'FontName', 'Times New Roman','FontSize',10,'FontWeight','bold');
%         end
%     else
%         rectangle('Position',[280, 0 + (i-9) * 20,20,10],'FaceColor',rgb(clr{i}));
%         if length(class_name{i}) > 8
%             a = class_name{i};
%             textstr = {a(1:8); a(9:length(a))};
%           text(300 ,(i-9) * 20 + 5 ,textstr,'FontName', 'Times New Roman','FontSize',10,'FontWeight','bold');
%         else
%           text(300 ,(i-9) * 20 + 5 ,class_name{i},'FontName', 'Times New Roman','FontSize',10,'FontWeight','bold');
%         end
%     end
% end
% PicPath = ['C:\Users\admin\Desktop\RLFFC����\�½��ͼ\' ,'KSC_gt.jpg'];
% print('-djpeg','-r200', PicPath);
