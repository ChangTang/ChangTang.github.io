# KSRC
Spatial-spectral kernel sparse representation for hyperspectral image classification, JSTARS, 2013
