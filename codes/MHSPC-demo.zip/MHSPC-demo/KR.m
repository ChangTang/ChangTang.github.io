function kr=KR(F,G)
nR_F=size(F,1);        
nR_G=size(G,1);     
mul=ones(nR_G,1);
FF=kron(F,mul);    
GG=repmat(G,nR_F,1);
kr=FF.*GG;
end
