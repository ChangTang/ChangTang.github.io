function  X = TCSmooth(B,delta,EdgeMap,eps_rel)
% Check input parameters.
if nargin < 3	
	error('Too few input parameters');
elseif nargin == 3
	eps_rel = 9e-4;   %Default 0.001
end
% Parameters for smoothing.
R = max(B(:));
mn = numel(B);
epsilon = R*mn*eps_rel;   %% default epsilon = R*mn*eps_rel;
mu = epsilon/mn;
Lmu = 8/mu ;
N = int32( ceil(2*sqrt(8*mn)*delta/epsilon) );

% Smooth solution via C function.
[X,k,epsilon_k] = tc_smooth(B,delta,epsilon,Lmu,mu,N,0,EdgeMap);
