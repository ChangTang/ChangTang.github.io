% % This demo code is for Ref. [1], and can only be used for non-comercial purpose. 
% % If you use our code, please cite our paper Ref. [1].
% % 
% % Code Author: Chang Tang
% % Email: happytangchang@gmail.com
% % Update Date: 2016.11.20
% % [1] Chang Tang, Chunping Hou, Yonghong Hou, Pichao Wang, Wanqing Li, "An effective edge-preserving smoothing method for image manipulation", Digital Signal Processing,
% % (2016), http://dx.doi.org/10.1016/j.dsp.2016.10.009

clear, clc
close all
disp('Starting TCSmooth...')
im_name = 'flower.jpg';   % input
Lambda=10;            % Lambda IN Eq(12)

OriginalColorImage=imread(im_name);  %Read ColorImage  rgb
[M,N,D]=size(OriginalColorImage);
GrayImage=im2double(rgb2gray(OriginalColorImage));
sigma=3;
[Gx Gy]=gradient(GrayImage);
GxFilter = lpfilter(Gx, sigma);
GyFilter = lpfilter(Gy, sigma);
GradientMap=GxFilter.*GxFilter+GyFilter.*GyFilter;
Threshold=2;
GradientMap(GradientMap>Threshold*mean(GradientMap(:)))=1;    %%For orig_jet.png threshold=14 will get better results
GradientMap(GradientMap<=Threshold*mean(GradientMap(:)))=0;
EdgeMap=GradientMap;

%% Three channel smoothing
R=double(OriginalColorImage(:,:,1));
G=double(OriginalColorImage(:,:,2));
B=double(OriginalColorImage(:,:,3));
delta =  Lambda*sqrt(M*N);   %% Eq.(22)
tic
[Rout] = TCSmooth(R,delta,EdgeMap);
[Gout] = TCSmooth(G,delta,EdgeMap);
[Bout] = TCSmooth(B,delta,EdgeMap);
toc
Output(:,:,1)=Rout;
Output(:,:,2)=Gout;
Output(:,:,3)=Bout;
figure,imshow(uint8(Output));
