function FBImg = lpfilter(FImg, sigma)     
%     FBImg = FImg;
        FBImg= conv2_sep(FImg, sigma);
end