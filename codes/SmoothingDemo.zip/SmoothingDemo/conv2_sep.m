function ret = conv2_sep(im, sigma)
  ksize = bitor(round(sigma),1);
  g = fspecial('gaussian', [1,ksize], sigma); 
  ret = conv2(im,g,'same');
  ret = conv2(ret,g','same');  
end